
 nullDC NAOMI v1.0.3 User Manual
 -------------------------------


 Table Of Contents:

 1. What is it?
  2 System Requirements
   3.1 Preparations/Other Requirements
   3.2 Running NAOMI ROM carts
   3.3 Running NAOMI GD-ROM images
    4. Usage
     5.1 Menus
     5.2 Plugin Specific Menus
      6. NetPlay
       7. Tips, Known Problems and Possible Solutions
        8. About


 Information for lazy people:
  If you just want to know how to run NAOMI games consult sections 3.1, 3.2 and 3.3.
  If you have problems running the emulator consult sections 2 and 7.
  If you want to learn about the options of the emulator consult sections 4 and 5.
  The emulator is pre-configured with options that will work for most people but are not the most accurate
  neither the faster ones. If you get errors on some games then change options or plugins.


 1. What is it?
 --------------

 nullDC NAOMI is a plugin based NAOMI arcade system emulator for x86 based computers running Windows Operating Systems.
 It's just like the original nullDC but with the NAOMI arcade system in mind.


 2. System Requirements
 ----------------------

   Minimum      :

   - Cpu        : Any CPU that supports SSE1 (AMD Athlon XP and later, Intel Pentium 3 and later)

   - Video Card : DirectX9 compliant video card with Projected Textures support. (Geforce MX, ATi Radeon)

   - Ram        : 256 MB

   - OS         : Windows 2000/XP/2003

   - The latest Redistributable of DirectX 9c. Latest version as of now can be found here:
	Online Installer:
     http://www.microsoft.com/downloads/details.aspx?FamilyID=2da43d38-db71-4c1b-bc6a-9b6652cd92a3&DisplayLang=en
	Offline Installer:
     http://www.microsoft.com/downloads/details.aspx?FamilyID=c1367bc3-4676-481a-bfaa-5c15d1d7199d&DisplayLang=en

   - VisualC++ 2005 Service Pack 1 Runtimes. They can be found here:
     http://www.microsoft.com/downloads/details.aspx?familyid=200B2FD9-AE1A-4A14-984D-389C36F85647&displaylang=en

   - winpcap. It's needed for modem emulation and it's not required otherwise. It can be found here:
     http://www.winpcap.org/install/default.htm


   The above requirements are considered as the absolute minimum in order to run the emulator with just a few errors
   as long as the selected plugins/options are supported by the hardware. The emulator is expected to malfunction
   or to not work at all on systems that don't meet these requirements.


   Recommended  :

   - CPU        : AMD 3000+ or Intel Pentium 4 at 2.6GHz or equivalent.

   - Video Card : DirectX9 compliant video card With shader model 2 support. (Geforce FX, ATi Radeon 9600)

   - RAM        : 512MB Dual channel DDR333

   Systems that meet the recommended requirements should get acceptable speeds for most games with minimal errors.


   Ideal        :

   - CPU        : Fast Intel Core 2 Duo or AMD 4000+ or equivalent.

   - Video Card : DirectX9 compliant video card With shader model 4 support. (Geforce 8 series, Radeon HD series)

   - RAM        : 1GB Dual channel DDR400

   Systems that meet the ideal requirements should get full speed for most games using even the most demanding options.


 Notes:

   - Some games have higher requirements than the rest and have speed issues even on systems that meet 
     the recommended requirements. In that case a system close to the ideal requirements is necessary to reach full speed.

   - Pentium 4 CPUs perform some tasks slower than other CPUs, thus the clock speed of 2.6GHz is needed.
     On the other hand, Pentium M CPUs perform the same tasks much faster
     (A Pentium M 750 at 1.86GHz should be enough to reach full speed).
     Intel Celeron and AMD Duron CPUs are slow and it's expected to perform worse than the rest.

   - nullDC will run on Windows Vista. However, hardware requirements will be a bit higher than the ones mentioned
     above and there will probably be sound related issues (as with many other applications running on Vista).


 3.1 Preparations/Other Requirements
 -----------------------------------

  Before running the emulator make sure that you have the necessary NAOMI BIOS file dumped from your NAOMI arcade system.
  nullDC currently supports early NAOMI BIOS files that lack GD-ROM support. One of those is the EPR-21576D Japanese BIOS.
  That's because nullDC doesn't emulate the NAOMI GD-ROM system yet.
  If your BIOS has GD-ROM support then the emulator will not be able to run any games and the NAOMI BIOS will show an error!
  The BIOS must be named "naomi_boot.bin" and be placed in the "Data" directory which is in the location where you installed
  the emulator.

 The emulator will fail to load if you don't have this file.


 Important Note: The keys are predefined and can't be changed for NAOMI! "5" inserts a coin, "1" starts the game, the arrow
 keys are movement, "z", "x", "c", "v", "a" and "s" represent buttons "A", "B", "C", "X", "Y" and "Z".


 3.2 Running NAOMI ROM carts
 ---------------------------

  Before reading any information about running NAOMI ROM carts you should be aware that the protection on them is not cracked yet.
  This means that even if you manage to run a game it will have serious ingame issues varying from collision detection issues to
  freezes and crashes. Only NAOMI GD-ROM images are considered "playable" for the time being so better go to section 3.3 if you
  just want to play some games. You have been warned!

  This is actually going to need some work. Each romset has to be uncompressed with all the files placed in a single directory.
  After this is done then a list file has to be manually created. Here's a step by step procedure for Virtua Striker 2 ver. 2000:

  1. We "learn" where the game loads each of its roms. We can do this using various ways.
    I personally use MAME Plus! (an unofficial MAME build). Selecting Virtua Striker 2 Ver. 2000 on the rom list shows me that it
    loads to the following memory areas:

 epr-21578e.bin 00200000 main 00000000
 epr-21578d.bin 00200000 main 00000000
 epr-21578b.bin 00200000 main 00000000
 epr-21577e.bin 00200000 main 00000000
 epr-21577d.bin 00200000 main 00000000
 epr-21576h.bin 00200000 main 00000000
 epr-21576g.bin 00200000 main 00000000
 epr-21576e.bin 00200000 main 00000000
 epr-21576d.bin 00200000 main 00000000
 epr-21576b.bin 00200000 main 00000000
 epr-21576.bin 00200000 main 00000000
 epr-22851.bin 00200000 main 00000000
 epr-22850.bin 00200000 main 00000000
 dcnaodev.bios 00080000 main 00000000
 epr21929c.22 00400000 user1 00000000 
 mpr21914.u1 00800000 user1 00800000
 mpr21915.u2 00800000 user1 01000000
 mpr21916.u3 00800000 user1 01800000
 mpr21917.u4 00800000 user1 02000000
 mpr21918.u5 00800000 user1 02800000
 mpr21919.u6 00800000 user1 03000000
 mpr21920.u7 00800000 user1 03800000
 mpr21921.u8 00800000 user1 04000000
 mpr21922.u9 00800000 user1 04800000
 mpr21923.u10 00800000 user1 05000000
 mpr21924.u11 00800000 user1 05800000
 mpr21925.u12 00800000 user1 06000000
 mpr21926.u13 00800000 user1 06800000
 mpr21927.u14 00800000 user1 07000000
 mpr21928.u15 00400000 user1 07800000

 The 1st column shows us the file name of each file. The 2nd shows us its size.
 The 3rd shows us if it's a BIOS file or actual data of the game
 (note that the "main" files are not used by nullDC NAOMI).
 The 4th shows us where the rom is loaded.


 2. We use what we "learned" to create a list file for the game using a text editor.

 First we give a name to the game. Then we list the used "user1" ROM images,
 the memory location they are placed to and their sizes. Then we use the 1st column of the previous example
 (we place the file name in "" and then add a comma).
 Then we use the 4th column of the previous example (adding a 0x in front of it and a comma in the end).
 Lastly we use the 2nd column of the previous example (adding a 0x in front of it again).

 The end result should be as follows:

 Virtua Striker 2 Ver. 2000 (JPN, USA, EXP, KOR, AUS)
 "epr21929c.22", 0x0000000, 0x0400000
 "mpr21914.u1", 0x0800000, 0x0800000
 "mpr21915.u2", 0x1000000, 0x0800000
 "mpr21916.u3", 0x1800000, 0x0800000
 "mpr21917.u4", 0x2000000, 0x0800000
 "mpr21918.u5", 0x2800000, 0x0800000
 "mpr21919.u6", 0x3000000, 0x0800000
 "mpr21920.u7", 0x3800000, 0x0800000
 "mpr21921.u8", 0x4000000, 0x0800000
 "mpr21922.u9", 0x4800000, 0x0800000
 "mpr21923.u10",0x5000000, 0x0800000
 "mpr21924.u11",0x5800000, 0x0800000
 "mpr21925.u12",0x6000000, 0x0800000
 "mpr21926.u13",0x6800000, 0x0800000
 "mpr21927.u14",0x7000000, 0x0800000
 "mpr21928.u15",0x7800000, 0x0400000

 In sort, if one line is as follows: mpr21923.u10 00800000 user1 05000000
 it'll eventually become as follows: "mpr21923.u10",0x5000000, 0x0800000

 After doing this for all "user1" files sequentially we save the text file giving it the extension .lst (ie: vs2_v2000.lst).
 If everything is done right then we can run the game by loading this .lst file with nullDC NAOMI.

 3.3 Running NAOMI GD-ROM images
 -------------------------------

 Running a GD-ROM game is eventually easier than running a ROM cart. First of all an iso image of a game is needed.
 NAOMI GD-ROM images have 3 tracks. The 3rd track is only needed (it should be a little more than 1GB in size).
 Another requirement is the decryprion key of your game. Each game has a different decryption key so it's not possible
 to run different games using the same key.

 Once both the 3rd track of the game and the key are obtained we have to decrypt the game.
 This is done by a little utility named gdrom2rom which decrypts each game using the provided key.

 The syntax of the utility is as follows:

 "gdrom2rom input_track game_key output_rom  game_name"
 
 "gdrom2rom" is the filename of the utility, "input_track" is the filename of the track we want to decrypt,
 "game_key" is the decryption key, "output_rom" is the filename of the track after we decrypt it
  and "game_name" is the name that the decrypted game will have.


 An example : gdrom2rom track03.bin 0123456789ABCDEF GGXX "Guilty Gear XX"

 This should decrypt the game Guilty Gear XX (using the 3rd track of the image we have which is named "track03.bin"),
 using the decryption key 0123456789ABCDEF (this key is just an example, not an actual key), naming the new decrypted
 file "GGXX" and naming the game "Guilty Gear XX"


 Decrypting a game will also create a list (.lst) file for it. You can run the game by loading this file with nullDC NAOMI.


 4. Usage
 --------

  Running the emulator and selecting the "Options -> Select Plugins" option will open the plugin selection menu.
  Here is a list of the plugins that come with the emulator:

 -PowerVR (Graphics) Plugins:

  "nullPVR" is the graphics plugin that was made by the nullDC team. It's the recommended graphics plugin.

  "Chankast's video" is a port of the PowerVR (graphics) core that was used on Chankast (another great Dreamcast emulator).

 -GDRom Plugins:

  "Image Reader" is used to run images of discs. It's not used by the NAOMI version of nullDC yet!

 -AICA (Sound) Plugins:

  "nullAICA" is the sound plugin that was made by the nullDC team. It's the recommended sound plugin.

  "Chankast's AICA" is a port of the AICA (sound) core that was used on Chankast (another great Dreamcast emulator).

  "Elsemi AICA" is an audio plugin that was made by Elsemi.

  "Empty AICA" is an audio plugin that produces no sound. It has reduced compatibility but is faster than the rest.

 -Maple (Input/Saves) Plugins:

   There is only one available maple plugin available that covers all the maple related functions. It has 2 divisions.
  Its first division handles each controller port and its second division handles the expansion slots of the peripheral
  connected to each controller port. Each division has various states. Divisions and states are explained below.

   Controller Division:

    "nullDC NAOMI JAMMA Controller [Winhook] acts like a JAMMA compatible controlling device is connected to the port.

    "None" acts like no controller is connected to the port.

 -External Device (Modem/Broadband Adaptor) Plugins:

  "nullExtDev" acts like a peripheral is connecter to the external device slot of the dreamcast.

 After all the necessary plugins are selected and the "OK" button is pressed the emulator window and console will appear.



 5.1 Menus
 ---------

  Here's a brief explanation of the menu options and their usage. Whenever a menu option has an arrow next to it it will
 expand revealing more options. If it doesn't have an arrow then clicking on it will pop up a configuration/message box.


 Clicking on the "File" tab will reveal 5 options.

  "Normal Boot" just opens the rom list selection menu.

  "HLE Boot" also just opens the rom list selection menu.

  "Open bin/elf" boots a NAOMI homebrew/development application/demo. It won't work for .bin ROMs or ISO images!

  "Load bin/elf" loads a NAOMI homebrew/development application/demo in memory. It won't work for .bin ROMs or ISO images!

  "Exit" exits the emulator... maybe.


 Clicking on the "System" tab will reveal 3 options.

  "Start" starts emulation.

  "Stop" stops emulation.

  "Reset" resets the emulator.


 Clicking on the "Options" tab will reveal the following options. Note that the options of "PowerVR", "GDRom",
 "AICA", "Maple" and "ExtDevice" change according to the plugins used.

  "nullDC Settings" has the core options of nullDC. It expands revealing some options.
   Clicking on the "Show" option will open a configuration box with the most of these options and more information.

    Available core options:

    "Enable Dynarec" enables the dynamic recompiler if selected. The interpreter is used when this is not selected.
    Recommended setting: Enabled

    "Enable CP Pass" enables a Dynarec optimization if selected. Recommended setting: Enabled

    "Underclock FPU" underclocks the Floating Point Unit if selected. It can speed things up if enabled but it might
     also break some games. Recommended setting: Disabled

    "Cable Type" defines what cable that the emulated Dreamcast uses to connect to the output screen.
     Recommended setting: Depends on the game. Change it if some games give an error about unsupported cable type.

  "Select Plugins" opens the plugins selection box.

  "PowerVR" contains the available options of the selected PowerVR (graphics) plugin.

  "GDRom" contains the available options of the selected GDRom plugin.

  "Aica" contains the available options of the selected AICA (sound) plugin.

  "Maple" contains the available options of the selected Maple (input/saves) plugin.

  "ExtDevice" contains the available options of the selected External Device (Modem/Broadband Adaptor) plugin.


 Clicking on the "Debug" tab will reveal the "Debugger" option which opens the SH4 debugger.


 Clicking on the "Profiler" tab will reveal 2 options.
  
  "Enable" enables the profiler.

  "Show" shows the profiler.


 Clicking on the "Help" tab will reveal the "About" option which opens the about box.



 5.2 Plugin Specific Menus
 -------------------------

  Each plugin can add its own menus to the interface of the emulator. These options will appear as an extension of the
 corresponding option that each plugin has under the "Options" tab.
  For example, if you run the emulator and go to "Options"->"PowerVR" you will notice some available options.
 Now if you select another PowerVR plugin and go to "Options"->"PowerVR" again you will see that some options
 are changed, added or deleted.

 Below is a list with the options of each plugin that comes with nullDC:

  Available options for PowerVR plugins:

    nullPVR:

    "Fullscreen" sets the fullscreen resolution. Setting it to "Auto" will set the resolution to maximum and also make
     a nice menu appear while in fullscreen. Use a specific resolution to get rid of the menu.
     Pressing Alt+Enter also switches between window and fullscreen mode.
     Recommended setting: 640x480, 960x720, 1280x960 and any 4:3 resolution that is a multiple of 640x480.
     Other settings might produce artifacts on some games with specific video cards (blame ATi).

    "Aspect Ratio" defines if the screen will be stretched to the used resolution, if an aspect ratio of 4:3 is
     going to be used with black borders on the sides or if an aspect ratio of 4:3 will be used with the screen
     expanding showing more stuff than it should. Recommended setting: Stretch is a safe option, you can also try the
     other 2 if you have widescreen monitor.

    "Palleted Textures" sets how palleted textures are going to be handled. Recommended setting: Dynamic, full if you
     have a video card with shader model 2 support. Otherwise switch between Static and Versioned if textures look wrong
     (ie: Soul Calibur with Static option) or if the game seems too slow (ie: Virtual On with Versioned option).

    "Sort" sets if and how the graphics will be sorted. Recommended setting: Per Triangle if you have a fast system.
     Otherwise, Per Strip. Note that some games need Sorting off to look good.

    "Modifier Volumes" sets if and how shadows will be drawn. Recommended setting: Normal if you have a fast system.

    "Z Buffer Mode" sets the used depth handling mode. Recommended setting: D24FS8. Note that D24FS8 is not supported by
     most video cards. The emulator will drop back to D24S8+FPE in that case which can be a bit slow for old systems. It's
     the second most accurate option however.
 
    "Show Fps" shows various GFX related statistics on the screen.

    "About" shows the about box.


    Chankast's video:

    "Fullscreen" enables fullscreen. You can enable or disable it only before starting emulation!
     You have to open nullDC.cfg and set a resolution manually or the emulator will use 640x480.
     Recommended setting: 640x480, 960x720, 1280x960 and any 4:3 resolution that is a multiple of 640x480.
     Other settings might produce artifacts on some games with specific video cards (blame ATi).

    "Use ZWrite" enable writes on the Z-Buffer. Recommended setting: Depends on the game.

    "Use Alpha Test ZWrite" enable writes of the alpha channel on the Z-Buffer. Recommended setting: Depends on the game.

    "Wireframe" enables wireframe mode. Recommended setting: Disabled.
 
    "Show Stats" shows various GFX related statistics on the screen.

    "About" shows the about box.


  Available options for GDROM plugins (not used by the NAOMI version of nullDC yet!):

    Image Reader:

    "Swap Disc" swaps the selected image with another one. Does not work for all cases.

    "Use Default Image" uses the selected default image every time emulation starts. Recommended setting: Disabled unless
     you plan to play the same single game for a long time.

    "Select Default Image" selects the ISO image that will be used in conjuction with the "Use Default Image" option.

    "Patch GDROM Region" patches GD-ROM images (GDIs) to boot on every BIOS/Flash version. Games with extra region
     protection will not boot unless you have a BIOS and flash file of the same region!

    "About" shows the about box.


  Available options for AICA plugins:

    nullAICA:

    "Config" opens a configuration box with various options. The function of each option is explained there. :)

    "Sync Audio" limits the emulator and the audio speed. Recommended setting: Enabled.

    "DSP Emulation" enables DSP emulation. Recommended setting: Disabled! DSP emulation is not done yet and will result in
     various problems. It might "work" for some games however.

    "Mute CDDA" mutes CDDA audio tracks. Recommended setting: Disabled.

    "Mute Sound" mutes sound. Recommended setting: Disabled.

    "About" shows the about box.


    Elsemi's AICA:

    "Sync Audio" limits the emulator and the audio speed. Recommended setting: Enabled.

    "About" shows the about box.


    Chankast's AICA:

    "About" shows the about box.


  Available options for Maple plugins:

    drkMapleDevices:

    No available options.


  Available options for ExtDevice plugins (not used by the NAOMI version of nullDC!):

    nullExtDev:

    This plugin just partially emulates the Dreamcast modem for now so the only working options are the "None" and "Modem".
    Recommended setting: None.



 6. NetPlay
 ----------

   NetPlay was dropped after v1.0.0 BETA 1. The current structure of the emulator makes it quite unusable.
   Use nullDC v1.0.0 BETA 1 along with the netplay addon if you really want to play online.



 7. Tips, Known Problems and Possible Solutions
 ----------------------------------------------

  - If the application or some of the plugins fail to start showing an error message you might not have the required runtimes
    and DirectX version installed. Go get them (links are on the Requirements section on the top of this document).

  - If the emulator cannot find the BIOS file then it is either missing or not named correctly. Note that
    Windows are configured to hide extensions for known file types and the name of the BIOS might show up as "naomi_boot.bin"
    but it's actually naomi_boot.bin.bin (or something). Try deleting the ".bin" part and see if the emulator still complains.

  - If the emulator fails to start with an opcode error message on the console then you either don't have correct BIOS
    files or the emulator is not compatible with the game you try. Try using the MMU version on interpreter mode to see if the
    game runs that way.

  - The MMU version is not recommended unless it's used on interpreter mode with games that make use of the MMU.
    It's slower than the non-MMU version.

  - The console that opens when you run the emulator displays some vital information which will help you report possible
    problems that a game may have. However, on some cases it may make the system slow.
    Open nullDC.cfg and set "Emulator.NoConsole=" to "1" to get rid of the console.

  - nullAICA and Elsemi's AICA sync audio to match the speed of the rest emulator parts. If a game runs below 100% its real
    speed, sound will be choppy and will have occasional "clicks". It would be better to use Chankast's AICA on that case.

  - The emulator might crash sometimes when trying to close it.

  - Some games may have problems if the "Constant Propagation Optimization Pass" option is enabled.

  - Systems below recommended requirements will get a speed boost with the "No AICA" plugin and might get better graphical
    results with Chankast's video PVR.

  - Some games have problems with specific plugins. Using a different plugin might fix some issues.

  - If you have graphical and audio issues try messing with the options of each plugin. Go to sections 5.1 and 5.2 for a
    description of most options. Keep in mind that the better something becomes, the slower it becomes too (unless broken).

  - If you can't get a compatible game to run then the plugins or options you use might create the problem. Try using others.
    It's possible that the romset/rom you use is corruped, partialy ripped, protected, decrypted with a wrong key
    or has a wrong .lst file. If nothing of the things above work then nullDC might not be compatible with that game.


 8. About
 --------

 Credits :

 drk||Raziel 	        : Main coder
 ZeZu 		        : Main coder
 GiGaHeRz 	        : Plugin work/misc stuff
 PsyMan 		: Mental support, management,
        		  beta testing & everything else
 General Plot 		: www & forum WIP
 soully 		: www WIP

 Beta testing :
  emwearz, Miretank, gb_away, Raziel, General Plot,
  Refraction, Ckemu,Falcon4ever, ChaosCode

 Many thanks to :
  Ector, Jim Denson, Flea, Jupi, Chankast team, lev|,
  GameCop and everyone else we forgot
